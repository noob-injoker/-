<template>
  <div>
    <el-table
      :data="tableData"
      :element-loading-text="loadingOptions.text"
      :element-loading-spinner="loadingOptions.icon"
      :element-loading-background="loadingOptions.bgColor"
      v-loading="!tableData.length"
      @cell-click="cellClick"
    >
      <el-table-column
        type="index"
        :label="indexOptions.label"
        :align="indexOptions.align"
        :width="indexOptions.width"
        :index="indexOptions.indexMethod"
        v-if="indexOptions && indexOptions.showIndex"
      ></el-table-column>
      <el-table-column type="expand" v-if="expandOptions">
        <template slot-scope="scope">
          <slot name="expand" :scope="scope"></slot>
        </template>
      </el-table-column>
      <template v-for="(item, index) in columns">
        <el-table-column
          v-if="item.prop"
          :label="item.label"
          :prop="item.prop"
          :align="item.align"
          :width="item.width"
          :key="index"
        >
          <template slot-scope="scope">
            <slot v-if="item.slots" :name="item.slots" :scope="scope"></slot>
            <template v-else>
              <div v-if='scope.row[item.label + "flag"]' class="flex a-center">
                <el-input
                  v-model="scope.row[item.prop]"
                  :ref="item.label"
                  @blur="onBlur(scope)"
                  @keydown.enter.native="onEnter(scope)"
                ></el-input>
                <div class="flex a-center">
                  <el-button type="text" style="margin-left: 8px;" @click="cancel(scope)">取消</el-button>
                  <el-button type="text" @click="confirm(scope)">确认</el-button>
                </div>
              </div>
              <span v-else>{{scope.row[item.prop]}}</span>
            </template>
          </template>
        </el-table-column>
        <el-table-column
          :key="index"
          :label="item.label"
          :align="item.align"
          :width="item.width"
          v-else
        >
          <template slot-scope="scope">
            <slot name="action" :scope="scope"></slot>
          </template>
        </el-table-column>
      </template>
    </el-table>
    <div v-if="showPagination" class="pagination">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-sizes="pageSizes"
        :page-size="pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="400"
      ></el-pagination>
    </div>
  </div>
</template>

<script>
export default {
  name: "AiTable",
  components: {},
  props: {
    tableData: {
      type: Array,
      required: true
    },
    columns: {
      type: Array,
      required: true
    },
    border: {
      type: Boolean,
      default: false
    },
    total: {
      type: [String, Number],
      default: 0
    },
    showPagination: {
      type: Boolean,
      default: true
    },
    currentPage: {
      type: Number,
      default: 1
    },
    pageSizes: {
      type: Array,
      default: () => [10, 20, 30, 40]
    },
    pageSize: {
      type: Number,
      default: 10
    },
    indexOptions: {
      type: Object
    },
    expandOptions: {
      type: Boolean,
      default: false
    },
    loadingOptions: {
      type: Object,
      default: () => {
        return {
          text: '',
          icon: "el-icon-loading",
          bgColor: 'hsla(0,0%,100%,.9)'
        }
      }
    }
  },
  data() {
    return {

    }
  },
  methods: {
    handleSizeChange(val) {
      this.$emit('handleSizeChange', val)
    },
    handleCurrentChange(val) {
      this.$emit('handleCurrentChange', val)
    },
    cellClick(row, column) {
      let flag = column.label + 'flag'
      this.$set(row, flag, true)
      // 延迟加载下一次的操作 保证能拿到dom
      this.$nextTick(() => {
        if (column.label !== '操作') this.$refs[column.label][0].focus()
         
      })
    },
    onBlur(scope) {
      scope.row[scope.column.label + 'flag'] = false
    },
    onEnter(scope) {
       scope.row[scope.column.label + 'flag'] = false
    },
    cancel(scope) {
      scope.row[scope.column.label + 'flag'] = false
      this.$emit('editCancel', scope)
    },
    confirm(scope) {
      scope.row[scope.column.label + 'flag'] = false
      this.$emit('editConfirm', scope)
    }
  },
  mounted() {
    this.tableData.map(item => {
      this.$set(item, 'clickFlag', 0)
      console.log(item)
    })
  },
  created() {

  },
  filters: {},
  computed: {},
  watch: {},
  directives: {}
}
</script>

<style scoped lang="scss">
.pagination {
  width: 100%;
  display: flex;
  margin-top: 26px;
  position: relative;
  right: 50px;
  justify-content: flex-end;
}
.flex {
  display: flex;
  align-items: center;
}
</style>
