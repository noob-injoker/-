<template>
  <div>
    <!-- <back-top> -->
        <router-view/>
    <!-- </back-top> -->
  </div>
</template>

<script>
export default {
  provide() {
    return {
      app: '我是app的数据'
    }
  }
}
</script>

<style>
 * {
   margin: 0;
   padding: 0;
 }
</style>
