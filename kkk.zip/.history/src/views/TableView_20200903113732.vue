<template>
  <div>
    <ai-table
        v-if="tableData.length"
        :table-data="tableData"
        :columns="columns"
        :total="total"
        :expand-options="true"
        :index-options="indexOptions"
        :loadingOptions="loadingOptions"
        @handleSizeChange="handleSizeChange"
        @handleCurrentChange="handleCurrentChange">
      <template v-slot:expand="scope">
        {{scope.scope.row.username}}
      </template>
     
      <template v-slot:action="scope">
        <el-button type="danger" @click="del(scope.scope)" size="mini">编辑</el-button>
        <el-button type="danger" @click="del(scope.scope)" size="mini">删除</el-button>
        <el-button type="danger" @click="del(scope.scope)" size="mini">分配角色</el-button>
      </template>
       <template v-slot:state="scope">
        <el-switch v-model="scope.scope.row.mg_state"></el-switch>
      </template>
    </ai-table>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: "TableView",
  components: {},
  props: {},
  data() {
    return {
      tableData: [],
      total: 0,
      // 表格的配置项
      columns: [
        {
          label: '姓名',
          prop: 'username',
          align: 'center',
          // width: '800'
        },
        {
          label: '角色',
          prop: 'role_name',
          align: 'center'
        },
        {
          label: '电话',
          prop: 'mobile',
          align: 'center'
        },
        {
          label: '邮箱',
          prop: 'email',
          align: 'right'
        },
        {
          label: '状态',
          prop: 'mg_state',
          align: 'center',
          slots: 'state'
        },
        {
          label: '操作',
          align: 'center'
        }
      ],
      indexOptions: {
        showIndex: true,
        label: '#',
        align: 'center',
        width: '200',
        indexMethod(index) {
          return index * 2
        }
      },
      loadingOptions: {
        text: '加载中...',
        bgColor: 'rgba(0, 0, 0, 0.8)'
      }
    }
  },
  methods: {
    getData() {
      axios.get('https://www.liulongbin.top:8888/api/private/v1/users?pagenum=1&pagesize=5', {
        headers: {
          Authorization: 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOjUwMCwicmlkIjowLCJpYXQiOjE1OTkwMDgxMTUsImV4cCI6MTU5OTA5NDUxNX0.0I9Cc4t2skb1YXftXim1o1A6t31TJJ0DtPLMSWowzSc'
        }
      }).then(res => {
        let data = res.data.data
        if (res.data.meta.status === 200) {
          this.tableData = data.users
          this.total = data.total
        }
        console.log(res)
      })
    },
    del(scope) {
      console.log(scope.row)
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
    }
  },
  mounted() {
    this.getData()
  },
  created() {

  },
  filters: {},
  computed: {},
  watch: {},
  directives: {}
}
</script>

<style scoped lang="scss">

</style>
