<template>
  <div>
    <ai-form :visible.sync="visible" :form-data="formData" @cancel="cancel" @ok="ok"></ai-form>
  </div>
</template>

<script>
export default {
  name: '',
  props: {
  },
  components: {

  },
  data() {
    return {
      formData: [
        {
          label: '用户名',
          // 表单元素的类型
          type: 'input',
          prop: 'username',
          // v-model绑定的值
          value: '',
          attrs: {
            placeholder: '请输入用户名',
            clearable: true
          },
          rules: [
            {
              required: true,
              message: '用户名不能为空',
              trigger: 'blur'
            }
          ],
        },
        {
          label: '密码',
          // 表单元素的类型
          type: 'input',
          prop: 'password',
          // v-model绑定的值
          value: '',
          rules: [
            {
              required: true,
              message: '密码不能为空',
              trigger: 'blur'
            }
          ],
          attrs: {
            placeholder: '密码',
            clearable: true,
            'show-password': true
          }
        },
        {
          label: '分配角色',
          type: 'select',
          value: '',
          prop: 'role',
          children: [
            {
              type: 'option',
              value: '选项1',
              label: '黄金糕'
            },
            {
              type: 'option',
              value: '选项2',
              label: '双皮奶'
            },
            {
              type: 'option',
              value: '选项3',
              label: '蚵仔煎'
            },
          ]
        }
      ],
    }
  },
  methods: {

  },
  mounted() {

  },
  watch: {

  },
  computed: {

  }
}
</script>

<style scoped lang='scss'>
</style>