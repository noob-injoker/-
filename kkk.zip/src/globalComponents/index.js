import Vue from 'vue'
import top from '../components/Top.vue'
import AiTable from "@/components/AiTable"
import AiForm from "@/components/AiForm"
import BackTop from "@/components/BackTop"
Vue.component('top', top)
Vue.component('aiTable', AiTable)
Vue.component('aiForm', AiForm)
Vue.component('backTop', BackTop)
