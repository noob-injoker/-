import api from '../../http/api'
import router from '../../router'
import {Message} from 'element-ui'

export default {
  // 开启命名空间 这个文件就是单独的一个vuex的模块
  namespaced: true,
  state: {
    menus: [],
    userList: [],
    total: 0
  },
  mutations: {
    setMenus(state, data) {
      state.menus = data
    },
    setUserList(state, data) {
      state.userList = data
    },
    setTotal(state, data) {
      state.total = data
    }
  },
  actions: {
    // 所有的请求都写在actions里面
    // action里面的方法可以传两个参数 第一个参数是整个store(vuex对象) 第二个参数是请求的参数
    async getMenus({commit}) {
      let res = await api.getMenus()
      if (res.meta.status === 200) {
        // 提交mutation
        commit('setMenus', res.data)
      }
    },
    async login({dispatch}, {username, password}) {
      let res = await api.login({
        username,
        password
      })
      if (res.meta.status === 200) {
        // 存储信息
        localStorage.setItem('adminToken', res.data.token)
        localStorage.setItem('adminUser', JSON.stringify(res.data))
        // 跳转路由
        router.push('/menus')
        // 提示用户
        Message.success('登录成功')
      } else {
        Message.error(res.meta.msg)
      }
    },
    async getUserList({commit}, {pagenum, pagesize,query}) {
      try {
        let res = await api.getUserList({
          pagenum,
          pagesize,
          query
        })
        if(res.meta.status === 200) {
          commit('setUserList', res.data.users)
          commit('setTotal', res.data.total)
        }
      } catch(err) {
        console.log(err)
      }
    },
    async deleteUser({dispatch}, {id, pagenum, pagesize, query}) {
      let res = await api.deleteUser(id)
      if (res.meta.status === 200) {
        Message.success('删除成功')
        // 调用获取用户列表的接口
        dispatch('getUserList', {
          pagenum,
          pagesize,
          query
        })
      }
    }
  }
}
