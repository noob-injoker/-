<template>
 <div>
   <!-- 父组件来决定这个输入框的placeholder和输入框的类型 -->
   <input v-bind='$attrs'>
   <br>
   <button @click="update">改变父组件的值</button>
 </div>
</template>

<script>
 export default {
   name: '',
   inheritAttrs: false,
   props: {
   },
   components: {

   },
   data () {
     return {
       msg: '我是子组件的值'
     }
   },
   methods: {
     update() {
       this.$listeners.send(this.msg)
     }
   },
   mounted() {
    //  console.log(this.$attrs)
   
    console.log(this.$listeners)
   },
   watch: {

   },
   computed: {

   }
 }
</script>

<style scoped lang='scss'>

</style>