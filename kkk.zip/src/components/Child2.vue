<template>
 <div>
   <!-- 我是第二个子组件
   <button @click="sendMsg">传值给第一个子组件</button>
   <div>
     <child-three></child-three>
   </div> -->
   <!-- <div style="color: blue">
     <slot></slot>
   </div>
   <div style="color: red">
     <slot name="red"></slot>
   </div> -->
   <slot name="msg" :msg='msg'></slot>
   <top></top>
 </div>
</template>

<script>
import childThree from './Child3'
 export default {
   name: '',
   props: {
   },
   components: {
     childThree
   },
   data () {
     return {
       msg: '我是子组件2的数据'
     }
   },
   methods: {
     sendMsg() {
       // 发送事件
       this.$bus.$emit('send', this.msg)
     }
   },
   mounted() {

   },
   watch: {

   },
   computed: {

   }
 }
</script>

<style scoped lang='scss'>

</style>