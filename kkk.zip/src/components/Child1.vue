<template>
 <div>
   <div>
     {{msg}} --- {{info}} --- {{title}}
   </div>
   <div>
     <button @click="updateMsg">直接修改父组件的值</button>
   </div>
 </div>
</template>

<script>
 export default {
   name: '',
   // 单向数据流
   props: {
     info: {
       type: String
     },
     title: {
       type: String
     }
   },
   components: {

   },
   data () {
     return {
       msg: '我是子组件'
     }
   },
   methods: {
     updateMsg() {
      //  this.$parent.info = '我是改变之后的值'
       this.$emit('update:title', '我是改变之后的标题')
     }
   },
   mounted() {
     // 接收事件
     this.$bus.$on('send', (data) => {
       console.log(data)
     })
   },
   watch: {

   },
   computed: {

   }
 }
</script>

<style scoped lang='scss'>

</style>