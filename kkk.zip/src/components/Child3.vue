<template>
 <div>
   我是第二个子组件的子组件
 </div>
</template>

<script>
 export default {
   name: '',
   props: {
   },
   components: {

   },
   inject: ['home', 'info', 'app'],
   data () {
     return {

     }
   },
   methods: {

   },
   mounted() {
     console.log(this.home)
     console.log(this.info)
     console.log(this.app)
   },
   watch: {

   },
   computed: {

   }
 }
</script>

<style scoped lang='scss'>

</style>