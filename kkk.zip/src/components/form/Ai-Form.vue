<template>
  <div>
    <el-dialog
        title="提示"
        :visible.sync="visible"
        width="30%"
    :before-close="handleClose">
      <slot name="content"></slot>
      <slot name="footer" v-if="$slots.footer"></slot>
      <span slot="footer" v-else>
        <el-button @click="cancel">取 消</el-button>
        <el-button type="primary" @click="ok">确 定</el-button>
     </span>
    </el-dialog>
  </div>

</template>

<script>
export default {
  name: "Ai-Form",
  components: {},
  props: {
    visible: {
      type: Boolean
    },
    showFooter: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {}
  },
  methods: {
    cancel() {
      this.$emit('cancel')
    },
    ok() {
      this.$emit('ok')
    },
    handleClose() {
      this.$parent.visible = false
    }
  },
  mounted() {
    console.log(this.$slots)
  },
  created() {

  },
  filters: {},
  computed: {},
  watch: {},
  directives: {}
}
</script>

<style scoped lang="scss">

</style>
