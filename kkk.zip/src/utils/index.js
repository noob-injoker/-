export let obj1 = {
  name: 'tom'
}
export let obj2 = {
  name: 'lili'
}
export function getData() {

}
export let checkLogin = () => {

}
export let num = 10

export default {
  obj: {
    name: 'jack'
  }
}