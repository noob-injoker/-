<template>
  <div>
    <child :placeholder='placeholder' :type='type' @send='send'></child>
    {{msg}}
  </div>
</template>

<script>
import child from '../components/Child'
export default {
  name: '',
  props: {
  },
  components: {
    child
  },
  data() {
    return {
      placeholder: '我是默认的值',
      type: 'password',
      msg: '我是父组件的值'
    }
  },
  methods: {
    send(data) {
      this.msg = data
    }
  },
  mounted() {

  },
  watch: {

  },
  computed: {

  }
}
</script>

<style scoped lang='scss'>
</style>