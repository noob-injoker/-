<template>
  <div>
    <el-button type="danger" @click="delUser">删除</el-button>
  </div>
</template>

<script>
import { createNamespacedHelpers } from 'vuex'
const userModule = createNamespacedHelpers('user')
const { mapState, mapActions } = userModule
export default {
  name: '',
  props: {
  },
  components: {

  },
  data() {
    return {
      pagenum: 1,
      pagesize: 5,
      query: ''
    }
  },
  methods: {
    ...mapActions(['getUserList', 'deleteUser']),
    delUser() {
      this.deleteUser({
        id: 503,
        pagenum: this.pagenum,
        pagesize: this.pagesize,
        query: this.query
      })
    }
  },
  mounted() {
    this.getUserList({
      pagenum: this.pagenum,
      pagesize: this.pagesize,
      query: this.query
    })
  },
  watch: {

  },
  computed: {
    ...mapState(['userList', 'total'])
  }
}
</script>

<style scoped lang='scss'>
</style>