<template>
  <div>
    <el-form>
      <el-form-item label="用户名">
        <el-input v-model="form.username" clearable></el-input>
      </el-form-item>
      <el-form-item label="密码">
        <el-input v-model="form.password" show-password clearable></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="submit">登录</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>


export default {
  name: '',
  props: {
  },
  components: {

  },
  data() {
    return {
      form: {
        username: 'admin',
        password: '123456'
      }
    }
  },
  methods: {
    submit() {
      this.$store.dispatch('user/login', {
        username: this.form.username,
        password: this.form.password
      })
    }
  },
  mounted() {

  },
  watch: {

  },
  computed: {
   
  }
}
</script>

<style scoped lang='scss'>
</style>