<template>

  <div style="height: 2000px;">
    <!-- <child-one :info='info' :title.sync='title' ref="child"></child-one> -->
    <child-two>
      <!-- <div>我是蓝色的插槽</div> -->
      <!-- <template #default>
        我是蓝色的插槽
      </template>
      <template v-slot:red>
        <div>我是红色的插槽</div>
      </template> -->
      <!-- <template #red>
        <div>我是红色的插槽</div>
      </template> -->

      <!-- scope代表整个作用域插槽 是一个对象 -->
      <template v-slot:msg='scope'>
        {{scope.msg}}
      </template>
    </child-two>
    <top></top>
  </div>
</template>

<script>
// import utils from '../utils'
// import {getData, num, checkLogin} from '../utils'
import * as utils from '../utils'
import childOne from '../components/Child1'
import childTwo from '../components/Child2'
export default {
  name: '',
  props: {
  },
  components: {
    childOne,
    childTwo
  },
  // 父组件给所有的子孙组件传递数据
  provide() {
    return {
      info: this.info,
      home: this
    }
  },
  inject: ['app'],
  data() {
    return {
      info: '我是父组件的数据',
      title: '我是父组件的标题'
    }
  },
  methods: {

  },
  mounted() {
    // let arr = [
    //   {
    //     name: 'jack',
    //     id: 1
    //   },
    //   {
    //     name: 'tom',
    //     id: 2
    //   },
    // ]
    // let obj = {
    //   name: 'jack',
    //   age: 20
    // }

    // find和findIndex
    // find: 查找数组当中满足条件的元素 如果满足 则返回该元素 如果不满足 则返回undefined
    // findIndex: 查找满足条件的元素的下标 如果满足 则返回对应的下标 如果不满足 则返回-1
    // let item = arr.find((item, index) => {
    //   return item.name === 'jack'
    // })
    //  let index = arr.findIndex((item, index) => {
    //   return item.name === 'jack'
    // })
    // console.log(item)
    // console.log(index)

    // console.log(utils)
    // console.log(this.$refs.child)
    console.log(this.app)
  },
  watch: {

  },
  computed: {

  }
}
</script>

<style scoped lang='scss'>
</style>
